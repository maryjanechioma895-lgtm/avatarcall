const cameraVideo = document.getElementById('cameraVideo');
const videoStage = document.getElementById('videoStage');
const emptyState = document.getElementById('emptyState');
const cameraButton = document.getElementById('cameraButton');
const stopButton = document.getElementById('stopButton');
const cameraStatus = document.getElementById('cameraStatus');
const backgroundChoice = document.getElementById('backgroundChoice');
const voiceChoice = document.getElementById('voiceChoice');
const effectNote = document.getElementById('effectNote');
const consentCheck = document.getElementById('consentCheck');
const avatarButton = document.getElementById('avatarButton');
const avatarStatus = document.getElementById('avatarStatus');
let cameraStream = null;
let avatarEnabled = false;

async function startCamera() {
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    cameraStatus.textContent = 'Camera unavailable';
    alert('Camera access needs a supported browser and a secure HTTPS website. Open the hosted site in Safari and try again.');
    return;
  }
  try {
    cameraStream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' }, audio: false });
    cameraVideo.srcObject = cameraStream;
    videoStage.classList.add('active');
    cameraStatus.textContent = 'Camera on';
    cameraButton.disabled = true;
    stopButton.disabled = false;
  } catch (error) {
    cameraStatus.textContent = 'Permission needed';
    alert('AvatarCall could not access the camera. Check Safari camera permissions and try again.');
  }
}
function stopCamera() {
  if (cameraStream) cameraStream.getTracks().forEach(track => track.stop());
  cameraStream = null;
  cameraVideo.srcObject = null;
  videoStage.classList.remove('active');
  cameraStatus.textContent = 'Camera off';
  cameraButton.disabled = false;
  stopButton.disabled = true;
}
cameraButton.addEventListener('click', startCamera);
stopButton.addEventListener('click', stopCamera);
backgroundChoice.addEventListener('change', () => {
  videoStage.classList.remove('bg-soft', 'bg-night', 'bg-studio');
  if (backgroundChoice.value !== 'none') videoStage.classList.add(`bg-${backgroundChoice.value}`);
});
const voiceDescriptions = {
  natural: 'Natural voice selected. No audio is being changed.',
  bright: 'Bright effect selected for the interface demo only. Live voice conversion is not connected.',
  deep: 'Deep effect selected for the interface demo only. Live voice conversion is not connected.',
  robot: 'Robot effect selected for the interface demo only. Live voice conversion is not connected.'
};
voiceChoice.addEventListener('change', () => effectNote.textContent = voiceDescriptions[voiceChoice.value]);
avatarButton.addEventListener('click', () => {
  if (!consentCheck.checked) {
    avatarStatus.textContent = 'Please confirm permission before enabling the avatar demo.';
    return;
  }
  avatarEnabled = !avatarEnabled;
  avatarButton.textContent = avatarEnabled ? 'Disable avatar demo' : 'Enable avatar demo';
  avatarStatus.textContent = avatarEnabled
    ? 'Consent confirmed. Avatar mode is marked on, but no face or voice transformation is running.'
    : 'Avatar demo is off.';
});
window.addEventListener('pagehide', stopCamera);
