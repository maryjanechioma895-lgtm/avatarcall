# AvatarCall — iPhone starter project

This ZIP contains a small mobile-web prototype for AvatarCall.

## What works in this starter
- Responsive interface designed for an iPhone browser.
- Local camera preview after the user grants camera permission.
- Background-style selector (changes the preview panel style only).
- Voice-effect selector (demo UI only).
- Consent checkbox and avatar-demo toggle.

## What is not implemented yet
- No real person-to-person calling or WebRTC signaling.
- No live voice conversion.
- No AI face/identity transformation.
- No AI background segmentation/replacement.
- No connection or overlay inside Signal, WhatsApp, Instagram, or other third-party apps.
- No claim of zero lag. Latency depends on network, device, codecs, and processing.

The next development stage would add a consent-based WebRTC calling service and then integrate clearly disclosed audio/video effects. Do not use another person's face or voice without their permission.

## Easiest free hosting path from iPhone
1. Extract this ZIP in the iPhone Files app.
2. Open https://dash.cloudflare.com/ in Safari and create/sign into an account.
3. For the simplest upload workflow, use a static hosting service that supports uploading a ZIP or connecting a repository. Cloudflare Pages typically deploys from a Git repository or supported build workflow; it may not offer a simple direct ZIP upload in every dashboard flow.
4. If the Cloudflare workflow asks for a Git repository, you can use GitHub in Safari: create a repository and upload these files, then connect that repository to Cloudflare Pages.
5. After deployment, open the HTTPS website in Safari. Tap “Turn camera on” and allow camera access.

## Local testing
Camera access generally requires HTTPS or localhost. Opening index.html directly from Files may not allow camera access. Deploy to an HTTPS host to test the camera preview.

## Files
- `index.html` — page structure
- `styles.css` — mobile styling
- `app.js` — camera preview and demo controls
